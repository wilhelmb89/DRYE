# Images used by the landing page

Upload to Shopify Files and select in each section's settings.

| Section | Setting | What the shot must show |
|---|---|---|
| drye-nt-hero | Hero image | A real nail tech at her desk — face visible, black nitrile gloves, DRYE at the cuff (the Meta ad image). Renders 1:1 on mobile, 21:9 on desktop. |
| drye-nt-desk | Card 1 image | Nail tech changing a nitrile glove between clients (4:5) |
| drye-nt-desk | Card 2 image | Her hands after several clients, gloves off (4:5) |
| drye-nt-desk | Card 3 image | DRYE under the glove during real work at the desk (4:5) |
| drye-nt-inside | Nitrile image | Bare hand in a black nitrile glove, mid-shift (16:10 mobile / 4:3 desktop) |
| drye-nt-inside | DRYE image | DRYE liner visible at the cuff under a nitrile glove |
| drye-nt-loop | Avatar 1–4 | The four grey avatar PNGs (`av-1`, `av-2`, `av-3`, `av-5`) |

Sections render a neutral `--bg-soft` box when no image is set, so the page never breaks.
