# DRYE — Nail Tech Landing Page (Shopify handoff)

Pixel-faithful port of `DRYE Nail Tech LP` into Shopify sections.
Mobile-first, one breakpoint at **760px** (the LP's breakpoint), plus 860px/1000px for two sections.

## Install

1. Copy `assets/*.css` → theme `assets/`
2. Copy `sections/*.liquid` → theme `sections/`
3. Copy `templates/page.nail-tech.json` → theme `templates/`
4. Create a Shopify page and assign the **nail-tech** template.
5. Upload the images (see `IMAGES.md`) and pick them in each section's settings.

Every section loads `drye-nt-base.css` (shared page primitives). Duplicate
`{{ 'x.css' | asset_url | stylesheet_tag }}` tags are deduped by the browser — leave them.

### Token dependency
The CSS uses the DRYE theme tokens (`--deep`, `--emerald`, `--border`, `--page-pad`, `--max-width`,
`--font-display`, `--space-*`, …). If the theme already ships `drye-base.css` (the file named
`theme/base.css` in the design project), those tokens exist — then **delete the `:root` block at the
top of `drye-nt-base.css`**. If not, keep it: it is a verbatim copy of that token set.

### Fonts
`drye-nt-base.css` imports DM Sans, Playfair Display and Clash Grotesk. For better LCP move them to
`layout/theme.liquid` as `<link rel="preconnect">` + `<link rel="stylesheet">` and delete the
`@import` lines.

## Section order on the page

| # | Section file | Screen |
|---|---|---|
| — | `drye-nt-hero` | Hero image + H1 + Trustpilot rotator |
| 01 | `drye-nt-desk` | "This is what it looks like at the desk." UGC swipe |
| 02 | `drye-nt-trapped` | Glove fills + humidity-per-client chart (dark) |
| — | `drye-nt-tradeoff` | Word cloud "One glove. Too many tradeoffs." |
| 03 | `drye-nt-loop` | "POV: you're stuck in the nail tech advice loop." |
| 04 | `drye-nt-barrier` | 14-day skin-barrier chart (dark) |
| 05 | `drye-nt-inside` | Nitrile alone vs Nitrile + DRYE |
| — | `drye-nt-nails` | "Who it's not for." |
| — | `drye-nt-cotton-q` | Pull quote: "is this cotton?" |
| — | `drye-liner-mechanism` | Cotton vs DRYE routing (dark, animated SVG) |
| — | `drye-liner-more-reviews` | "From real customers." carousel |
| — | `drye-nt-close` | CTA + source line |

## Behaviour notes

- **Hero rotator**: vanilla JS in the section, 6.5 s interval, pauses on hover and on dot click,
  respects `prefers-reduced-motion`.
- **UGC row + reviews carousel**: native scroll-snap swipe, scrollbar hidden, "SWIPA" hint animation
  (mobile only). No JS.
- **"Keep reading"**: anchor link to `#drye-nt-trapped`; smooth scrolling comes from
  `html { scroll-behavior: smooth }` in `drye-nt-base.css`.
- **Charts**: pure inline SVG + CSS keyframes (`g-fill`, `g-wipe`), all disabled under
  `prefers-reduced-motion`.
- SVG `clipPath`/`gradient` ids are prefixed per section to stay unique on a page with several sections.
